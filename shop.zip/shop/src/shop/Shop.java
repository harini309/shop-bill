/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shop;

/**
 *
 * @author Koteswaran
 */
import java.util.Scanner;

public class Shop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String productName;
    int quantity ;
    double price ;
    double totalPrice ;
    Scanner scan = new Scanner(System.in);
      System.out.println("Enter product details,");
      System.out.print("Name: ");
      productName = scan.nextLine();
      System.out.print("Quantity: ");
      quantity = scan.nextInt();
      System.out.print("Price (per item): ");
      price = scan.nextDouble();
      totalPrice = price * quantity ;
      System.out.println("\n productname = " + productName); 
      System.out.println( "\n quantity= " + quantity );
      System.out.println( "\n price= " + price);
    System.out.println("\nTotal Price = " + totalPrice );
  }

}
    
    
